const CONFIG = {
  // Replace these UUIDs with the UUIDs used by your ESP32/Arduino BLE firmware.
  serviceUUID: "0000ffe0-0000-1000-8000-00805f9b34fb",
  rxCharacteristicUUID: "0000ffe1-0000-1000-8000-00805f9b34fb",
  txCharacteristicUUID: "0000ffe2-0000-1000-8000-00805f9b34fb"
};

document.getElementById("serviceUuidText").textContent = CONFIG.serviceUUID;
document.getElementById("rxUuidText").textContent = CONFIG.rxCharacteristicUUID;
document.getElementById("txUuidText").textContent = CONFIG.txCharacteristicUUID;

const $ = id => document.getElementById(id);
let bluetoothDevice = null, rxChar = null, txChar = null;
let packetCount = 0, commandCount = 0, currentMode = "Mouse";
let drawing = false, lastX = null, lastY = null;

const canvas = $("drawCanvas"), ctx = canvas.getContext("2d");
function resizeCanvas() {
  const old = document.createElement("canvas");
  old.width = canvas.width; old.height = canvas.height;
  if (canvas.width && canvas.height) old.getContext("2d").drawImage(canvas,0,0);
  const rect = canvas.getBoundingClientRect(), dpr = devicePixelRatio || 1;
  canvas.width = Math.max(1, Math.floor(rect.width*dpr));
  canvas.height = Math.max(1, Math.floor(rect.height*dpr));
  ctx.setTransform(dpr,0,0,dpr,0,0);
  ctx.lineCap = "round"; ctx.lineJoin = "round"; ctx.lineWidth = 3;
  if (old.width) ctx.drawImage(old,0,0,old.width/dpr,old.height/dpr);
}
window.addEventListener("resize", resizeCanvas);
resizeCanvas();

function toast(msg){ $("toast").textContent=msg; $("toast").classList.add("show"); setTimeout(()=>$("toast").classList.remove("show"),2200); }

function setConnected(connected) {
  const pill = $("connectionPill");
  pill.className = "pill " + (connected ? "online" : "offline");
  pill.innerHTML = `<span class="dot"></span> ${connected ? "Connected" : "Disconnected"}`;
  $("connectBtn").textContent = connected ? "Connected" : "Connect Device";
  $("disconnectBtn").disabled = !connected;
  $("deviceStatusValue").textContent = connected ? "Connected" : "Disconnected";
  $("liveBadge").textContent = connected ? "LIVE" : "OFFLINE";
}

async function connectBluetooth() {
  if (!navigator.bluetooth) {
    toast("Web Bluetooth is not supported. Use Chrome or Edge on HTTPS.");
    return;
  }
  try {
    bluetoothDevice = await navigator.bluetooth.requestDevice({
      filters: [{ services: [CONFIG.serviceUUID] }],
      optionalServices: [CONFIG.serviceUUID]
    });
    bluetoothDevice.addEventListener("gattserverdisconnected", onDisconnected);
    const server = await bluetoothDevice.gatt.connect();
    const service = await server.getPrimaryService(CONFIG.serviceUUID);
    rxChar = await service.getCharacteristic(CONFIG.rxCharacteristicUUID);
    try { txChar = await service.getCharacteristic(CONFIG.txCharacteristicUUID); } catch(e) { txChar = null; }
    await rxChar.startNotifications();
    rxChar.addEventListener("characteristicvaluechanged", handleBluetoothData);
    $("deviceName").textContent = bluetoothDevice.name || "AirGesture Device";
    $("deviceMeta").textContent = "BLE GATT connected";
    setConnected(true);
    toast("Device connected");
  } catch(err) {
    console.error(err);
    toast(err.name === "NotFoundError" ? "No Bluetooth device selected." : "Connection failed.");
  }
}

function onDisconnected() {
  rxChar = null; txChar = null;
  setConnected(false);
  $("deviceMeta").textContent = "Bluetooth device disconnected";
  toast("Device disconnected");
}

function disconnectBluetooth(){
  if (bluetoothDevice?.gatt?.connected) bluetoothDevice.gatt.disconnect();
  else onDisconnected();
}

function decode(value){
  return new TextDecoder().decode(value).trim();
}

function handleBluetoothData(event){
  const raw = decode(event.target.value);
  packetCount++;
  $("packetCount").textContent = packetCount;
  $("lastUpdate").textContent = new Date().toLocaleTimeString();

  // Expected JSON example:
  // {"gesture":"NEXT","mode":"Presentation","pen":0,"battery":82,"ax":0.12,"ay":0.04,"az":0.98,"gx":3.2,"gy":-1.4,"gz":0.7,"x":123,"y":87,"drawing":1}
  try {
    const data = JSON.parse(raw);
    updateFromPacket(data);
  } catch {
    // Also accept simple key=value pairs separated by commas:
    // gesture=NEXT,mode=Presentation,pen=1,battery=82,ax=.1,...
    const data = {};
    raw.split(",").forEach(part => {
      const [k,...v] = part.split("=");
      if(k && v.length) data[k.trim()] = v.join("=").trim();
    });
    if(Object.keys(data).length) updateFromPacket(data);
  }
}

function updateFromPacket(d){
  if(d.mode) setMode(String(d.mode), false);
  if(d.gesture) {
    $("gestureValue").textContent = d.gesture;
    commandCount++;
    $("commandCount").textContent = commandCount;
    addHistory(d.gesture, currentMode);
    executeCommand(String(d.gesture));
  }
  if(d.pen !== undefined) $("penValue").textContent = (d.pen==1 || String(d.pen).toLowerCase()==="down" || String(d.pen).toLowerCase()==="true") ? "Pen Down" : "Pen Up";
  if(d.battery !== undefined) {
    const b = Number(d.battery);
    $("batteryValue").textContent = `${Math.round(b)}%`;
    $("batteryHero").textContent = `${Math.round(b)}%`;
  }
  [["ax","ax"],["ay","ay"],["az","az"],["gx","gx"],["gy","gy"],["gz","gz"]].forEach(([id,key])=>{
    if(d[key]!==undefined) $(id).textContent = Number(d[key]).toFixed(2);
  });
  if(d.x !== undefined && d.y !== undefined && currentMode==="Drawing") {
    const w = canvas.clientWidth, h = canvas.clientHeight;
    const x = Math.max(0,Math.min(w,Number(d.x))), y = Math.max(0,Math.min(h,Number(d.y)));
    const isDown = d.drawing===undefined ? $("penValue").textContent==="Pen Down" : !!Number(d.drawing);
    drawPoint(x,y,isDown);
  }
}

function setMode(mode, send=true){
  const normalized = ["Mouse","Presentation","Media","Drawing","Password"].find(m=>m.toLowerCase()===String(mode).toLowerCase()) || "Mouse";
  currentMode=normalized;
  $("modeValue").textContent=normalized;
  document.querySelectorAll(".mode").forEach(b=>b.classList.toggle("active",b.dataset.mode===normalized));
  $("canvasHint").style.display = normalized==="Drawing" ? "none" : "grid";
  if(send) sendCommand({type:"mode",mode:normalized});
}
document.querySelectorAll(".mode").forEach(btn=>btn.addEventListener("click",()=>setMode(btn.dataset.mode)));

async function sendCommand(obj){
  if(!txChar) return;
  try {
    const bytes = new TextEncoder().encode(JSON.stringify(obj)+"\n");
    if(txChar.writeValueWithoutResponse) await txChar.writeValueWithoutResponse(bytes);
    else await txChar.writeValue(bytes);
  } catch(e){ console.warn("TX failed",e); }
}

function executeCommand(g){
  const s=g.toUpperCase();
  // These commands are sent to the connected host/device. Actual OS-level
  // mouse/media/keyboard control must be implemented by your firmware or
  // a companion application. The web app visualizes and routes the command.
  if(currentMode==="Drawing") return;
  sendCommand({type:"command",command:s,mode:currentMode});
}

function addHistory(gesture,mode){
  const history=$("history");
  const empty=history.querySelector(".empty"); if(empty) empty.remove();
  const item=document.createElement("div");
  item.className="history-item";
  item.innerHTML=`<div><strong>${escapeHtml(gesture)}</strong><div><span>${new Date().toLocaleTimeString()}</span></div></div><em>${escapeHtml(mode)}</em>`;
  history.prepend(item);
  while(history.children.length>20) history.lastElementChild.remove();
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}

function drawPoint(x,y,isDown){
  if(isDown){
    if(lastX!==null) { ctx.beginPath(); ctx.moveTo(lastX,lastY); ctx.lineTo(x,y); ctx.stroke(); }
    else { ctx.beginPath(); ctx.arc(x,y,1.5,0,Math.PI*2); ctx.fill(); }
  }
  lastX=x; lastY=y;
  if(!isDown){lastX=null;lastY=null;}
}
canvas.addEventListener("pointerdown",e=>{
  if(currentMode!=="Drawing") return;
  const r=canvas.getBoundingClientRect(); drawPoint(e.clientX-r.left,e.clientY-r.top,true);
  drawing=true;
});
canvas.addEventListener("pointermove",e=>{
  if(!drawing || currentMode!=="Drawing") return;
  const r=canvas.getBoundingClientRect(); drawPoint(e.clientX-r.left,e.clientY-r.top,true);
});
window.addEventListener("pointerup",()=>{drawing=false;lastX=null;lastY=null;});

$("clearBtn").addEventListener("click",()=>{ctx.clearRect(0,0,canvas.clientWidth,canvas.clientHeight);toast("Canvas cleared");});
$("saveBtn").addEventListener("click",()=>{
  const a=document.createElement("a"); a.download=`airgesture-drawing-${Date.now()}.png`; a.href=canvas.toDataURL("image/png"); a.click();
});
$("historyClear").addEventListener("click",()=>{$("history").innerHTML='<div class="empty">No gestures received yet.</div>';});

$("connectBtn").addEventListener("click",()=>bluetoothDevice?.gatt?.connected ? toast("Device is already connected.") : connectBluetooth());
$("disconnectBtn").addEventListener("click",disconnectBluetooth);

setInterval(()=>{
  const activity = Math.min(100, 2 + (packetCount % 100));
  $("activityBar").style.width = `${activity}%`;
},500);

// Demo mode: allows the interface to be tested without hardware.
// Remove this block when connecting your actual device.
window.airGestureDemo = function(packet){
  updateFromPacket(packet);
};
