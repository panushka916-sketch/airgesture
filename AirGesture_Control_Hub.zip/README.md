# AirGesture Control Hub

A mobile-friendly Bluetooth monitoring and visualization web app for an air-gesture wearable.

## Run it

Web Bluetooth requires a secure context. The simplest free options are:

1. GitHub Pages
2. Netlify
3. Vercel

For local development, use a local HTTPS server or a browser setup that permits Web Bluetooth on localhost.

## Bluetooth firmware protocol

Edit `app.js` at the top and replace the three UUIDs with the UUIDs used by your ESP32/Arduino BLE firmware.

The app expects notifications from the RX characteristic.

Recommended JSON packet:

{"gesture":"NEXT","mode":"Presentation","pen":0,"battery":82,"ax":0.12,"ay":0.04,"az":0.98,"gx":3.2,"gy":-1.4,"gz":0.7,"x":123,"y":87,"drawing":1}

Fields:
- gesture: detected gesture/command
- mode: Mouse, Presentation, Media, Drawing, Password
- pen: 0/1
- battery: percentage
- ax, ay, az: accelerometer readings
- gx, gy, gz: gyroscope readings
- x, y: drawing coordinates
- drawing: 0/1

A simple key=value format is also accepted:
gesture=NEXT,mode=Presentation,pen=1,battery=82,ax=.1,ay=.2,az=.9,gx=1,gy=2,gz=3

## Important limitation

A normal browser cannot directly take over the computer's operating-system cursor, keyboard, presentation controls, or media keys merely because it received a BLE gesture. The web app can receive and display commands and send commands back to the BLE device.

For true OS-level Mouse/Presentation/Media control, implement HID functionality on the wearable (for example BLE HID on an ESP32 variant that supports it), or use a small companion desktop application that receives the web/device commands and maps them to OS actions.

## Included

- Bluetooth device discovery and GATT connection
- Connection status
- Five operating modes
- Live gesture display
- Pen Up/Pen Down status
- Battery status
- MPU6050 values
- Packet/command performance counters
- Command history
- Drawing canvas
- Save drawing as PNG
- Clear/reset canvas
- Responsive mobile layout
